import mosspy

userid = 604014254

m = mosspy.Moss(userid, "python")


# Submission Files
m.addFilesByWildcard("old/*.py")
m.addFilesByWildcard("sub/*.py")
 

url = m.send()
print(url)