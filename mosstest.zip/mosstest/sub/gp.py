from __future__ import annotations
from boframework.kernels import Matern
from scipy.linalg import cho_solve, cholesky, solve_triangular
from scipy.optimize import minimize
from typing import Callable, Tuple, Union, Type
import copy
from operator import itemgetter
import numpy as np

# Class Structure


class GPRegressor:
    """
    Gaussian process regression (GPR).

    Arguments:
    ----------
    kernel : kernel instance,
        The kernel specifying the covariance function of the GP.

    noise_level : float , default=1e-10
        Value added to the diagonal of the kernel matrix during fitting.
        It can be interpreted as the variance of additional Gaussian
        measurement noise on the training observations.

    n_restarts : int, default=0
        The number of restarts of the optimizer for finding the kernel's
        parameters which maximize the log-marginal likelihood. The first run
        of the optimizer is performed from the kernel's initial parameters,
        the remaining ones (if any) from thetas sampled log-uniform randomly
        (for more details: https://en.wikipedia.org/wiki/Reciprocal_distribution)
        from the space of allowed theta-values. If greater than 0, all bounds
        must be finite. Note that `n_restarts == 0` implies that one
        run is performed.

    random_state : RandomState instance
    """

    def __init__(self,
                 kernel: Matern,
                 noise_level: float = 1e-10,
                 n_restarts: int = 0,
                 random_state: Type[np.random.RandomState] = np.random.RandomState
                 ) -> None:

        self.kernel = kernel
        self.noise_level = noise_level
        self.n_restarts = n_restarts
        self.random_state = random_state(4)

    def optimisation(self,
                     obj_func: Callable,
                     initial_theta: np.ndarray,
                     bounds: Tuple
                     ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Function that performs Quasi-Newton optimisation using L-BFGS-B algorithm.

        Note that we should frame the problem as a minimisation despite trying to
        maximise the log marginal likelihood.

        Arguments:
        ----------
        obj_func : the function to optimise as a callable
        initial_theta : the initial theta parameters, use under x0
        bounds : the bounds of the optimisation search

        Returns:
        --------
        theta_opt : the best solution x*
        func_min : the value at the best solution x, i.e, p*
        """
        # TODO Q2.2
        # Implement an L-BFGS-B optimisation algorithm using scipy.minimize built-in function
        result = minimize(obj_func, x0=initial_theta, method='l-bfgs-b', bounds=bounds)
        theta_opt = result.x
        func_min = self.log_marginal_likelihood(theta_opt)

        return np.asarray(theta_opt), np.asarray(func_min)
        # FIXME

        # raise NotImplementedError

    def fit(self, X: np.ndarray, y: np.ndarray) -> GPRegressor:
        """
        Fit Gaussian process regression model.

        Arguments:
        ----------
        X : ndarray of shape (n_samples, n_features)
            Feature vectors or other representations of training data.
        y : ndarray of shape (n_samples, n_targets)
            Target values.

        Returns:
        --------
        self : object
            The current GPRegressor class instance.
        """
        # TODO Q2.2
        # Fit the Gaussian process by performing hyper-parameter optimisation
        # using the log marginal likelihood solution. To maximise the marginal
        # likelihood, you should use the `optimisation` function

        # HINT I: You should run the optimisation (n_restarts) time for optimum results.

        # HINT II: We have given you a data structure for all hyper-parameters under the variable `theta`,
        #           coming from the Matern class. You can assume by optimising `theta` you are optimising
        #           all the hyper-parameters.

        # HINT III: Implementation detail - Note that theta contains the log-transformed hyperparameters
        #               of the kernel, so now we are operating on a log-space. So your sampling distribution
        #               should be uniform.


        # FIXME

        def minus_log_marginal_likelihood(theta):
            return -self.log_marginal_likelihood(theta)

        self._kernel = copy.deepcopy(self.kernel)

        self._X_train = X
        self._y_train = y

        # initial parameters
        r = self.random_state
        theta_init = self._kernel.theta
        theta_opt, log_mar = self.optimisation(minus_log_marginal_likelihood, initial_theta=theta_init, bounds=self._kernel.bounds)
        best_fit = theta_opt
        for i in range(self.n_restarts):
            temp_init = r.uniform(self._kernel.bounds[:, 0], self._kernel.bounds[:, 1])
            temp_opt, temp_log_mar = self.optimisation(minus_log_marginal_likelihood, initial_theta=temp_init, bounds=self._kernel.bounds)
            if log_mar < temp_log_mar:
                best_fit = temp_opt
                log_mar = temp_log_mar

        self._kernel.theta = best_fit
        return self



    def predict(self, X: np.ndarray, return_std: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        """
        Predict using the Gaussian process regression model.

        In addition to the mean of the predictive distribution, optionally also
        returns its standard deviation (`return_std=True`).

        Arguments:
        ----------
        X : ndarray of shape (n_samples, n_features)
            Query points where the GP is evaluated.
        return_std : bool, default=False
            If True, the standard-deviation of the predictive distribution at
            the query points is returned along with the mean.

        Returns (depending on the case):
        --------------------------------
        y_mean : ndarray of shape (n_samples, n_targets)
            Mean of predictive distribution a query points.
        y_std : ndarray of shape (n_samples, n_targets), optional
            Standard deviation of predictive distribution at query points.
            Only returned when `return_std` is True.
        """
        # TODO Q2.2
        # Implement the predictive distribution of the Gaussian Process Regression
        # by using the Algorithm (1) from the assignment sheet.

        # FIXME
        n_samples = X.shape[0]
        n_target = self._X_train.shape[1]

        # self._kernel = copy.deepcopy(self.kernel)
        # calculate the covariance matrices
        ky = self._kernel(self._X_train)
        ky += self.noise_level*np.eye(ky.shape[0])
        kx = self._kernel(self._X_train, X)
        kxT = kx.T

        # cholesky decomposition Lower triangular
        l = cholesky(ky, lower=True)

        # solve for alpha
        alpha = cho_solve((l, True), self._y_train)
        y_mean = kxT @ alpha

        if not return_std:
            return y_mean

        # solve for v
        v =solve_triangular(l, kx, lower=True)

        # calcualte mean and vairance
        kxx = self._kernel(X)
        variance = kxx - v.T @ v
        y_std = np.sqrt(np.diag(variance))

        return y_mean.reshape(n_samples,n_target), y_std.reshape(n_samples,n_target)

        # raise NotImplementedError

    def fit_and_predict(self, X_train: np.ndarray, y_train: np.ndarray, X_test: np.ndarray,
                        return_std: bool = False, optimise_fit: bool = False
                        ) -> Union[
        Tuple[dict, Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]],
        Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]
    ]:
        """
        Predict and/or fit using the Gaussian process regression model.

        Based on the value of optimise_fit, we either perform predictions with or without fitting the GP first.

        Arguments:
        ----------
        X_train : ndarray of shape (n_samples, n_features)
            Feature vectors or other representations of training data.
        y_train : ndarray of shape (n_samples, n_targets)
            Target values.
        X_test : ndarray of shape (n_samples, n_features)
            Query points where the GP is evaluated.
        return_std : bool, default=False
            If True, the standard-deviation of the predictive distribution at
            the query points is returned along with the mean.
        optimise_fit : bool, default=False
            If True, we first perform fitting and then we continue with the 
            prediction. Otherwise, perform only inference.

        Returns (depending on the case):
        --------------------------------
        kernel_params: the kernel (hyper)parameters, optional. Only for `optimise_fit=True` case; 
            HINT: use `get_params()` fuction from kernel object. 
        y_mean : ndarray of shape (n_samples, n_targets)
            Mean of predictive distribution a query points.
        y_std : ndarray of shape (n_samples, n_targets), optional
            Standard deviation of predictive distribution at query points.
            Only returned when `return_std` is True.

        """
        # TODO Q2.6a
        # Implement a fit and predict or only predict scenarios. The course of action
        # should be chosen based on the variable `optimise_fit`.
        if optimise_fit:
            # FIXME
            self = self.fit(X_train,y_train)

            kernel_param = self._kernel.get_params()
            if return_std:
                y_mean, y_std = self.predict(X_test, True)
                return kernel_param,y_mean,y_std
            else:
                y_mean = self.predict(X_test)
                return kernel_param,y_mean
            # raise NotImplementedError
        else:
            self._kernel = copy.deepcopy(self.kernel)
            self._X_train = X_train
            self._y_train = y_train

            if return_std:
                y_mean, y_std = self.predict(X_test, True)
                return y_mean, y_std

            else:
                y_mean = self.predict(X_test)
                return y_mean


            # FIXME
            # raise NotImplementedError

    def log_marginal_likelihood(self, theta: np.ndarray) -> float:
        """
        Return log-marginal likelihood of theta for training data.

        Arguments:
        ----------
        theta : ndarray of shape (n_kernel_params,)
            Kernel hyperparameters for which the log-marginal likelihood is
            evaluated.

        Returns:
        --------
        log_likelihood : float
            Log-marginal likelihood of theta for training data.
        """
        # TODO Q2.2
        # Compute the log marginal likelihood by using the Algorithm (1)
        # from the assignment sheet.

        kernel = self._kernel
        kernel.theta = theta

        X = self._X_train
        y = self._y_train

        # cholesky decomposition Lower triangular

        l = cholesky(kernel(X,X) + self.noise_level*np.eye(X.shape[0]),lower=True)

        # solve for alpha
        alpha = cho_solve((l,True), y)

        n = X.shape[0]
        # compute log likelihood

        log_mar = -0.5 *(y.T@alpha) - np.sum(np.log(np.diagonal(l))) - 0.5*n*np.log(2*np.pi)
        log_mar = np.sum(log_mar)

        return log_mar

        # FIXME
        raise NotImplementedError


