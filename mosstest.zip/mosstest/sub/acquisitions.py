import numpy as np
from scipy.stats import norm

# Functional Structure


def probability_improvement(X: np.ndarray, X_sample: np.ndarray,
                            gpr: object, xi: float = 0.01) -> np.ndarray:
    """
    Probability improvement acquisition function.

    Computes the PI at points X based on existing samples X_sample using
    a Gaussian process surrogate model

    Arguments:
    ----------
        X: ndarray of shape (m, d)
            The point for which the expected improvement needs to be computed.

        X_sample: ndarray of shape (n, d)
            Sample locations

        gpr: GPRegressor object.
            Gaussian process trained on previously evaluated hyperparameters.

        xi: float. Default 0.01
            Exploitation-exploration trade-off parameter.

    Returns:
    --------
        PI: ndarray of shape (m,)
    """
    # TODO Q2.4

    # calculate best surrogate score
    yhat = gpr.predict(X_sample)

    best = np.max(yhat)
    # calculate the mean and std for the surrogate function at samples points
    mu, std = gpr.predict(X, True)

    # calculate PI
    z = (mu-best-xi)/std
    prob = norm.cdf(z)

    return prob.reshape(X.shape[0],)

    # FIXME

    # raise NotImplementedError


def expected_improvement(X: np.ndarray, X_sample: np.ndarray,
                         gpr: object, xi: float = 0.01) -> np.ndarray:
    """
    Expected improvement acquisition function.

    Computes the EI at points X based on existing samples X_sample using
    a Gaussian process surrogate model

    Arguments:
    ----------
        X: ndarray of shape (m, d)
            The point for which the expected improvement needs to be computed.

        X_sample: ndarray of shape (n, d)
            Sample locations

        gpr: GPRegressor object.
            Gaussian process trained on previously evaluated hyperparameters.

        xi: float. Default 0.01
            Exploitation-exploration trade-off parameter.

    Returns:
    --------
        EI : ndarray of shape (m,)
    """

    # TODO Q2.4
    # Implement the expected improvement acquisition function
    expect = 0

    # calculate the surogate model's means and stds from the sample data points
    mu, std = gpr.predict(X, True)

    # calculate the prediction for the query points
    yhat = gpr.predict(X_sample)
    best = np.max(yhat)

    z = (mu - best - xi) / std

    if np.all(std) == 0:
        return expect
    else:
        expect = (mu-best-xi)*norm.cdf(z) + std*norm.pdf(z)
        expect = np.reshape(expect,-1)

    return expect

    # raise NotImplementedError
